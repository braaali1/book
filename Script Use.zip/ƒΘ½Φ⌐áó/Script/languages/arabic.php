﻿<?php
//======================================================================\\
// 		                                    			      \\
// 									       \\
// 										\\
// 										 \\
//======================================================================\\

// Character encoding
$LNG['charset'] = "utf-8";
// الصفحة الرئيسية والتسجيل
$LNG['user_success'] = 'تم انشاء المستخدم بنجاح!';
$LNG['user_exists'] = 'هذا الاسم غير متوفر ';
$LNG['email_exists'] = 'البريد الالكتروني مستخدم';
$LNG['all_fields'] = 'جميع الحقول مطلوبه';
$LNG['user_alnum'] = 'يجب ان يتكون الاسم من حروف وارقام فقط.';
$LNG['user_too_short'] = 'يجب ان يكون الاسم بين 3 الى 32 حرف او رقم';
$LNG['invalid_email'] = 'بريد الكتروني خاطئ!';
$LNG['invalid_user_pw'] = 'خطا في اسم المستخدم او كلمه السر';
$LNG['invalid_captcha'] = 'خطا في رمز التحقق';
$LNG['log_out'] = 'تسجيل الخروج';
$LNG['hello'] = 'مرحبا';
$LNG['visitor'] = 'زائر';
$LNG['register'] = 'التسجيل';
$LNG['login'] = 'تسجيل الدخول';
$LNG['password'] = 'كلمة المرور';
$LNG['username'] = 'اسم المستخدم';
$LNG['email'] = 'الايميل';
$LNG['captcha'] = 'رمز التحقق';
$LNG['username_or_email'] = 'اسم المستخدم او الايميل';
$LNG['welcome_title'] = 'مرحبا';
$LNG['welcome_desc'] = 'بك في شبكتنا الاجتماعية المطورة الجديدة';
$LNG['welcome_about'] = 'العب,شارك حياتك,انشر,علق على منشورات من تحب في موقعنا ';
$LNG['forgot_password'] = '؟ نسيت كلمه السر';
$LNG['all_rights_reserved'] = 'جميع الحقوق محفوظه';

// NOTIFICATION BOXES //

	 
	  	
$LNG['settings_saved'] = 'تم حفظ الاعدادات';
$LNG['nothing_saved'] = 'لم يحفظ شيئ';
$LNG['general_settings_saved'] = 'تم حفظ الاعدادات العامه بنجاح';
$LNG['overall_settings_saved'] = 'تم تحديث اعداداتك بنجاح!';
$LNG['general_settings_unaffected'] = 'لم يحدث تغييرات';
$LNG['password_changed'] = 'تم تغيير كلمه السر';
$LNG['nothing_changed'] = 'لم يتغير شيء';
$LNG['password_success_changed'] = 'تم تغيير كلمه سرك بنجاح يمكنك الان استخدامها.';
$LNG['incorrect_date'] = 'التاريخ المحدد غير صالح، الرجاء اختيار تاريخ صالح.';
$LNG['password_not_changed'] = 'لم يتم تغيير كلمه سرك!';
$LNG['image_saved'] = 'تم حفظ الصوره';
$LNG['profile_picture_saved'] = 'تم تغيير صورتك الشخصيه بنجاح.';
$LNG['error'] = 'خطأ';
$LNG['no_file'] = 'انت لم تقم باختيار اي ملفات لرفعها او ان الملفات المرفوعه فارغه!';
$LNG['file_exceeded'] = 'الملف المختار يجب ان لا يتعدى  <strong>%s</strong> ميقا بايت';
$LNG['file_format'] = 'امتداد المف المختار غير مدعوم حاليا <strong>%s</strong> امتداد الملف';
$LNG['image_removed'] = 'الصوره حذفت';
$LNG['profile_picture_removed'] = 'تم حذف صورتك الشخصيه';
$LNG['bio_description'] = 'السيره الذاتيه يجب ان تكون بين %s احرف او رموز';
$LNG['valid_email'] = 'يرجى ادخال بريد الكتروني صحيح';
$LNG['valid_url'] = 'يرجى ادخال رابط موقع الكترون صالح';
$LNG['background_changed'] = 'تم تغيير هذه الخلفيه بنجاح';
$LNG['background_not_changed'] = 'لم يتم تغيير هذه الخلفيه';
$LNG['password_too_short'] = 'يجب على كلمه سر ان تتكون من  <strong>3</strong> حروف.';
$LNG['something_went_wrong'] = 'هناك شيء خاطئ';
$LNG ['username_not_found'] = 'نحن couldn\' ر العثور على اسم المستخدم المختار. ';
$LNG ['userkey_not_found'] = 'اسم المستخدم أو إعادة تعيين المفتاح على خطأ، تأكد you\ قد قمت بإدخال بيانات الاعتماد الصحيحة.';
$LNG ['password_reseted'] = ' يمكنك الان, قد تم تغيير كلمه سرك بنجاح لتسجيل دخولك الى موقعنا.';
$LNG ['email_sent'] = 'رسائل البريد الإلكتروني المرسلة';
$LNG ['email_reset'] = ' تم إرسال رسالة بريد إلكتروني تحتوي على إرشادات إعادة تعيين كلمة المرور. أرجو أن تسمحوا لنا تصل إلى 24 ساعة تسليم الرسالة، وأيضا التحقق من مربع البريد المزعج الخاص بك إذا نت can\ ر العثور في علبة الوارد الخاصة بك.';
$LNG ['user_deleted'] = '" حذف المستخدم';
$LNG ['user_has_been_deleted'] = 'المستخدم مع المعرف: تم حذف <strong>% s</strong>.';
$LNG ['user_not_deleted'] = 'المستخدم المحدد (معرف: % s) لا يمكن حذف.';
$LNG ['user_not_exist'] = 'المستخدم المحدد غير موجود."';
$LNG ['theme_changed'] = ' تغيير المظهر';
$LNG ['theme_success_changed'] = 'تم بنجاح تغيير المظهر.';
$LNG ['theme_not_changed'] = 'المظهر عذراً ولكن لا يمكن تغيير';
$LNG ['notif_saved'] = 'تغيير الإشعارات';
$LNG ['notif_success_saved'] = 'تم بنجاح تحديث الاشعارات.';

// MAIL CONTENT //
$LNG['welcome_mail'] = 'مرحبا بك في %s';
$LNG['user_created'] = 'شكر لك على التسجيل <strong>%s</strong><br /><br />اسمك: <strong>%s</strong><br />كلمة سرك: <strong>%s</strong><br /><br />يمكنك الدخول عبر الرابط: <a href="%s" target="_blank">%s</a>';
$LNG['recover_mail'] = 'استعادة كلمة السر';
$LNG['recover_content'] = 'تم طلب استعادة كلمة المرور, وإذا كنت لم تقدم هذا الإجراء الرجاء تجاهل هذه الرسالة. <br /><br />اسمك: <strong>%s</strong><br />رقم استرجاعك: <strong>%s</strong><br /><br />يمكنك اعاده تعيين كلمه سرك عبر اتباع هذا الرابط: <a href="%s/index.php?a=recover&r=1" target="_blank">%s/index.php?a=recover&r=1</a>';
$LNG['ttl_comment_email'] = '%s علق على رسالتك';
$LNG['comment_email'] = 'مرحبا <strong>%s</strong>,<br /><br /><strong><a href="%s">%s</a></strong> علق على  <strong><a href="%s">الرسالة.</a></strong>
<br /><br /><span style="color: #aaa;"> لقد تم ارسال هذه الرساله اوتوماتيكا اذا اردت عدم تلقي مثل هذه الرساله, اذا كنت لاتريد استلام هذا النوع من الرسائل  <strong>%s</strong> في المستقبل, رجاءا <a href="%s">الغاء الاشتراك</a>.</span>';
$LNG['ttl_like_email'] = '%s اعجب برسالتك';
$LNG['like_email'] = 'مرحبا <strong>%s</strong>,<br /><br /><strong><a href="%s">%s</a></strong> معجب ب <strong><a href="%s">رسالتك.</a></strong>
<br /><br /><span style="color: #aaa;">هذه الرسالة ترسل تلقائيا, اذا اردت عدم تلقي مثل هذه الرساله <strong>%s</strong> في المستقبل, رجاءا <a href="%s">الغي الاشتراك</a>.</span>';

// ADMIN PANEL //

$LNG['general_link'] = 'عام';
$LNG['security_link'] = 'الامان';
$LNG['manage_users'] = 'اداره المستخدمين';

$LNG['theme_install'] = 'لتنصيب قالب جديد قم برفعه على <strong>القوالب</strong> ملف';
$LNG['theme_author_homepage'] = 'زيارة موقع الكاتب';
$LNG['theme_version'] = 'الاصدار';
$LNG['theme_active'] = 'تفعيل';
$LNG['theme_activate'] = 'مفعل';
$LNG['theme_by'] = 'من قبل';

// FEED //
$LNG['welcome_feed_ttl'] = 'مرحبا بك في حائط المنشورات';
$LNG['welcome_feed'] = 'جميع منشورات اصدقائك ستراها هنا لا تنسى البقاء متصلا هنا';
$LNG['welcome_timeline_ttl'] = 'مرحبا بك في حائطك';
$LNG['welcome_timeline'] = 'جميع منشوراتك ومنشورات الاصقاء التي تشاركها  ستجدها هنا';
$LNG['leave_comment'] = 'اترك تعليقك..';
$LNG['post'] = 'نشر';
$LNG['view_more_comments'] = 'عرض المزيد من التعليقات';
$LNG['this_post_private'] = 'هذا المنشور خاص';
$LNG['this_post_public'] = 'هذا المنشور عام';
$LNG['this_post_public'] = 'هذه الرساله عامه';
$LNG['delete_this_comment'] = 'حذف هذه التعليق';
$LNG['delete_this_message'] = 'حذف هذه الرساله';
$LNG['report_this_message'] = 'التبليغ عن هذه الرساله';
$LNG['report_this_comment'] = 'التبليغ عن هذا التعليق';
$LNG['view_more_messages'] = 'عرض المزيد';
$LNG ['food'] = 'أكلت في: <strong>% s</strong>';
$LNG ['visited'] = 'زرت: <strong>% s</strong>';
$LNG ['played'] = 'لعبت في: <strong>% s</strong>';
$LNG ['watched'] = 'شاهدت: <strong>% s</strong>';
$LNG ['listened'] = 'لقد استمعت: <strong>% s</strong>';
$LNG ['shared'] = 'أنا المشتركة <a href="%s"> <strong>رسالة</strong></a> من <a href="%s"> <strong>% s</strong></a>.';
$LNG ['form_title'] = 'تحديث الحالة الخاصة بك';
$LNG ['comment_wrong'] = 'حدث خطأ، الرجاء قم بتحديث الصفحة وحاول مرة أخرى.';
$LNG ['comment_too_long'] = 'عذراً، لكن العدد الأقصى للأحرف المسموح بها لكل تعليق <strong>% s</strong>.';
$LNG ['comment_error'] = 'عذراً، ونحن couldn\ لن تستطيعوا نشر التعليق، الرجاء قم بتحديث الصفحة وحاول مرة أخرى.';
$LNG['message_hidden'] = 'متاسفون.لكن هذه الرساله خاصه فقط كاتب الرساله يمكنه تعيين من يستطيع رؤيتها';
$LNG['message_hidden_ttl'] = 'خصوصيه الرساله';
$LNG['login_to_lcs'] = 'يرجى تسجيل الدخول للاعجاب او مشاركه هذا المنشور';
$LNG['comment'] = 'تعليق';
$LNG['share'] = 'مشاركة';
$LNG['shared_success'] = 'لقد تم نشر المنشور بنجاح الى <a href="%s"><strong>حائطك</strong></a>.';
$LNG['no_shared'] = 'متاسفون لم نتمكن من نشر ررسالتك يرجى تحديث الصفحه والمحاوله فيما بعد';
$LNG['share_title'] = 'مشاركه هذا المنشور';
$LNG['share_desc'] = 'هل انت متاكد وتود نشر هذه الرساله على حائطك؟';
$LNG ['cancel'] = 'إلغاء الأمر';
$LNG ['close'] = 'إغلاق';


// REPORT //

	 	  	
$LNG['1_not_exists'] = 'الرساله المبلغ عنها غير موجوده!!';
$LNG['0_not_exists'] = 'المنشور المبلغ عنه غير موجود اصلا.';
$LNG['1_already_reported'] = 'لقد قمت بالفعل بالتبليغ عن هذه الرساله وسيتم التصرف قريبا ..شكرا لك';
$LNG['0_already_reported'] = 'لقد قمت بالفعل بالتبليغ عن هذه الرساله وسيتم التصرف قريبا ..شكرا لك.';
$LNG['1_is_safe'] = 'هذه الرساله مصنفه كـ <strong>امنه</strong>من قبل الاداره شكرا لتعقيبك ';
$LNG['0_is_safe'] = 'هذا التعليق مصنف كـ<strong>امن</strong> من قبل الاداره شكرا لتعقيبك';
$LNG['1_report_added'] = 'لقد تم التبليغ عن هذه الرساله شكرا لك';

$LNG['0_report_added'] = 'لقد تم التبليغ عن هذا التعليق شكرا لك';
$LNG['1_report_error'] = 'ناسف.لكن هناك عطل ما في التبليغ عن هذه الرساله يرجى تحديث الصفحه';
$LNG['0_report_error'] = 'ناسف لكن هناك حدث شء غير متوقع اثناء التبليغ عن التعليق حاول مجددا';
$LNG['1_is_deleted'] = 'لقد تم حذف الرساله .شكرا لتعقيبك';
$LNG['0_is_deleted'] = 'لقد تم حذف التعليق . شكرا لتعقيبك';
// SIDEBAR //
$LNG['filter_events'] = 'ترتيب الأحداث';
$LNG['archive'] = 'الأرشيف';
$LNG['all_events'] = 'جميع المصنفات';
$LNG['sidebar_map'] = 'المكان';
$LNG['sidebar_food'] = 'الوجبات';
$LNG['sidebar_visited'] = 'الزوار';
$LNG['sidebar_movie'] = 'الافلام';
$LNG['sidebar_game'] = 'الالعاب';
$LNG['sidebar_picture'] = 'الصور';
$LNG['sidebar_video'] = 'مقاطع الفيديو';
$LNG['sidebar_music'] = 'الموسيقى';
$LNG['sidebar_shared'] = 'المنشورات';
$LNG['all_time'] = 'جميع الاوقات';
$LNG['subscriptions'] = 'الاصدقاء';
$LNG['subscribers'] = 'لديك نفس الاصدقاء';
$LNG['welcome'] = 'مرحبا';
$LNG['filter_gender'] = 'تصنيف الجنس';
$LNG['sidebar_male'] = 'ذكر';
$LNG['sidebar_female'] = 'انثى';
$LNG['all_genders'] = 'جميع الاجناس';
$LNG['online_friends'] = 'الاصدقاء المتواجدون';
$LNG['sidebar_likes'] = 'الاعجابات';
$LNG['sidebar_comments'] = 'التعليقات';
$LNG['sidebar_messages'] = 'الرسائل';
$LNG['sidebar_chats'] = 'الدردشه';
$LNG['sidebar_suggestions'] = 'اقترح اصدقاء';
$LNG['sidebar_trending'] = 'المواضيع الشائعة';

// MESSAGES / CHAT //
 	  	
$LNG['lonely_here'] = 'انه وحيد! .ساعده لايجاد الاصدقاء';
$LNG['write_message'] = 'كتابه رساله...';
$LNG['chat_too_long'] = 'نأسف، ولكن الحد الأقصى من الأحرف المسموح بها لكل رسالة محادثة <strong>%s</strong>.';
$LNG['blocked_by'] = 'لم تصل هذه الرساله <strong>%s</strong> قام بحضرك';
$LNG['blocked_user'] = 'لم تصل الرساله وذالك لانك محضور <strong>%s</strong>.';
$LNG['chat_self'] = 'يتعذر تسليم رسائل المحادثة مع نفسك.';
$LNG['chat_no_user'] = 'يجب عليك اختيار مستخدم للدردشه معه';
$LNG['view_more_conversations'] = 'عرض المزيد من المحادثات';
$LNG['block'] = 'حظر';
$LNG['unblock'] = 'اعاده فتح';
$LNG['conversation'] = 'المحادثات';
$LNG['start_conversation'] = 'يمكنك بدء المحداثه عبر اختيار احد اصدقائك';
$LNG['send_message'] = 'ارسال الرساله';


// MESSAGE FORM //
$LNG['label_food'] = 'اضافه مكان اكلت فيه';
$LNG['label_game'] = 'اضافه لعبه لعبتها';
$LNG['label_movie'] = 'اضافه فلم شاهدته';
$LNG['label_visited'] = 'اضافه مكان زرته';
$LNG['label_map'] = 'اضافه مكان';
$LNG['label_video'] = '(عدم وضع فيديو بحقوق) مشاركه فيديو من يوتيوب او فيمو';
$LNG['label_music'] = 'اضافه انشوده سمعتها';
$LNG['label_image'] = 'رفع صوره';
$LNG ['message_form'] = 'ماذا يخطر في بالك؟';
$LNG ['file_too_big'] = 'حجم الملف المحدد (% s) كبير جداً، حجم ملف أقصى المسموح به <strong>% s</strong>.';
$LNG ['format_not_exist'] = 'تنسيق الملف المحدد (% s) غير صحيح، الرجاء تحميل فقط تنسيق الصورة <strong>% s</strong>.';
$LNG ['privacy_no_exist'] = ' الخصوصية المحددة غير موجودة، الرجاء قم بتحديث الصفحة وحاول مرة أخرى.';
$LNG ['event_not_exist'] = 'الحدث المحدد غير موجودة، الرجاء قم بتحديث الصفحة وحاول مرة أخرى.';

$LNG ['unexpected_message'] = 'لقد حدث خطأ غير متوقع، يرجى تحديث الصفحة وحاول مرة أخرى.';
$LNG ['message_too_long'] = 'عذراً، لكن العدد الأقصى للأحرف المسموح بها لكل رسالة <strong>% s</strong>.';
$LNG ['files_selected'] = 'صورة مختارة.';
$LNG ['too_many_images'] = 'الحد الأقصى لعدد الصور التي يسمح لتحميل كل رسالة هو <strong>% s</strong>، التي حاولت لتحميل الصور <strong>% s</strong>.';


// USER PANEL //
$LNG['user_menu_general'] = 'عام';
$LNG['user_menu_security'] = 'كلمه السر';
$LNG['user_menu_avatar'] = 'الحساب الشخصي';
$LNG['user_menu_notifications'] = 'الاشعارات';

$LNG['user_ttl_general'] = 'الاعدادات العامه';
$LNG['user_ttl_security'] = 'اعدادات كلمه السر';
$LNG['user_ttl_avatar'] = 'اعدادات الملف الشخصي';
$LNG['user_ttl_notifications'] = 'اعدادات الاشعارات';

$LNG['user_desc_general'] = 'تغيير خصوصيه حسابك واعدادان نشر الموقع';
$LNG['user_desc_security'] = 'تغيير كلمه سرك';
$LNG['user_desc_avatar'] = 'تغيير صورتك الشخصيه';
$LNG['user_desc_cover'] = 'تغيير صوره الغلاف ';
$LNG['user_desc_notifications'] = 'تغيير اعدادات الاشعارات';

$LNG['ttl_background'] = 'الخلفيات';
$LNG['sub_background'] = 'وضع خلفيه لحسابك الشخصي او صفحتك';

$LNG['ttl_first_name'] = 'الاسم الاول';
$LNG['sub_first_name'] = 'ادخل اسمك الاول';

$LNG['ttl_last_name'] = 'اسم عائلنك';
$LNG['sub_last_name'] = 'ادخل اسم عائلتك.';

$LNG['ttl_email'] = 'البريد الالكتروني';
$LNG['sub_email'] = 'الايميل سوف لن يظهر.';

$LNG['ttl_location'] = 'الموقع';
$LNG['sub_location'] = 'اين تعيش؟';

$LNG['ttl_website'] = 'الموقع الالكتروني';
$LNG['sub_website'] = 'اذا كنت تملك مدونه شخصيه او موقع شخصي قم بوضعه.';

$LNG['ttl_gender'] = 'الجنس';
$LNG['sub_gender'] = 'قم باختيار جنسك ..ذكر او انثى';

$LNG['ttl_profile'] = 'الحساب الشخصي';
$LNG['sub_profile'] = 'خصوصيه حسابي';

$LNG ['ttl_messages'] = 'رسالة الخصوصية';
$LNG['sub_messages'] = 'الطريقة الافتراضية في نشر رسائل.';

$LNG['ttl_offline'] = 'حاله الدردشه';
$LNG['sub_offline'] = 'مركز رؤيه الدردشه';

$LNG['ttl_facebook'] = 'فيسبوك';
$LNG['sub_facebook'] = 'معرف حسابك في فيسبوك.';

$LNG['ttl_twitter'] = 'تويتر';
$LNG['sub_twitter'] = 'معرف حسابك في تويتر.';

$LNG ['ttl_google'] = 'جوجل +';
$LNG ['sub_google'] = 'الخاص بك جوجل + معرف الشخصية';

$LNG ['ttl_bio'] = 'بيو';
$LNG ['sub_bio'] = 'عنك (160 حرفاً أو أقل).';

$LNG['ttl_born'] = 'تاريخ الولاده';
$LNG['sub_born'] = 'قم باختيار تاريخ ولادتك ';

$LNG['ttl_not_verified'] = 'غير متطابق';
$LNG['ttl_verified'] = 'تاكيد';
$LNG['sub_verified'] = 'شعار التحقق في ملف المستخدم';

$LNG['ttl_upload_avatar'] = 'رفع الصوره المختاره';
$LNG['ttl_delete_avatar'] = 'حذف صورتك الشخصيه الحاليه';

$LNG['opt_public'] = 'عام';
$LNG['opt_private'] = 'خاص';
$LNG['opt_semi_private'] = 'مسموح للمشتركين فقط';

$LNG['opt_offline_off'] = 'متواجد';
$LNG['opt_offline_on'] = 'دائما غير متواجد';

$LNG['no_gender'] = 'بدون جنس';
$LNG['male'] = 'ذكر';
$LNG['female'] = 'انثى';

$LNG['ttl_upload'] = 'رفع';
$LNG['ttl_password'] = 'كلمه السر';
$LNG['sub_password'] = 'ادخل كلمه السر الجديده على ان لا تقل عن 3 حروف';
$LNG['save_changes'] = 'حفظ التغييرات';
$LNG['ttl_upload_photo'] = 'رفع الصوره';
$LNG['ttl_upload_cover'] = 'رفع غلاف';
$LNG['ttl_delete_photo'] = 'حذف الصوره';

$LNG['ttl_notificationl'] = 'الاعجاب الاشعارات';
$LNG['sub_notificationl'] = 'اضهار التنبيهات والاشعارات لـ <strong>الاعجابات</strong>';

$LNG['ttl_notificationc'] = 'اشعارات التعليقات';
$LNG['sub_notificationc'] = 'عرض التنبيهات والاشعارات لـ <strong>التعليقات</strong>';

$LNG['ttl_notifications'] = 'اشعار الرسائل';
$LNG['sub_notifications'] = 'ايقاف الاشعارات ل <strong>مشاركة الرسائل</strong>';

$LNG['ttl_notificationd'] = 'اشعارات الدردشه';
$LNG['sub_notificationd'] = 'ايقاف التنبيهات والمؤثؤات الصوتيه في <strong>الدردشه</strong>';

$LNG['ttl_email_comment'] = 'البريد على التعليقات';
$LNG['sub_email_comment'] = 'استقبال بريد الكتروني ينبهني بان شخص معجب بتعليقي';

$LNG['ttl_email_like'] = 'البريد على الاعجابات';
$LNG['sub_email_like'] = 'استقبال بريد الكتروني ينبهني بان شخص معجب باحد منشوراتي.';
$LNG['ttl_email_new_friend'] = 'بريد عند الصداقة';
$LNG['sub_email_new_friend'] = 'استلم بريد عندما يضيفني احد';

$LNG['ttl_notificationf'] = 'اشعارات الصداقة';
$LNG['sub_notificationf'] = ' ايقاف الاشعارات ل <strong>اضافة الاصدقاء</strong>';

$LNG['ttl_sound_nn'] = 'صوت الاشعارات';
$LNG['sub_sound_nn'] = 'سماع صوت عند استلام اشعار';

$LNG['ttl_sound_nc'] = 'صوت الدردشة';
$LNG['sub_sound_nc'] = 'سماع صوت عند استلام رسالة';


$LNG['user_ttl_sidebar'] = 'الاعدادات';

// ADMIN PANEL //
$LNG['admin_login'] = 'دخول الاداره';
$LNG['admin_user_name'] = 'اسم المستخدم';
$LNG['desc_admin_user'] = 'ضع اسم المستخدم';
$LNG['admin_pass'] = 'كلمه السر';
$LNG['desc_admin_pass'] = 'ضع كلمه السر';
$LNG['admin_menu_general'] = 'الاعدادات العامه';
$LNG['admin_menu_security'] = 'كلمه السر';
$LNG['admin_menu_users'] = 'ادااره المستخدمين';
$LNG['admin_menu_logout'] = 'تسجيل الخروج';
$LNG['admin_menu_stats'] = 'الاحصائيات';
$LNG['admin_menu_users_settings'] = 'اعدادت المستخدمين';
$LNG['admin_menu_themes'] = 'القوالب';
$LNG['admin_menu_manage_reports'] = 'اداره التبليغات';
$LNG['admin_menu_manage_ads'] = 'اداره الاعلانات';

	 
$LNG['admin_ttl_sidebar'] = 'القائمه';
$LNG['admin_ttl_general'] = 'الاعدادات العامه';
$LNG['admin_ttl_security'] = 'اعدادات كلمه السر';
$LNG['admin_ttl_themes'] = 'القوالب';
$LNG['admin_ttl_users'] = 'اداره الاعضاء';
$LNG['admin_ttl_stats'] = 'الاحصائيات';
$LNG['admin_ttl_users_settings'] = 'اعدادات الاعضاء';
$LNG['admin_ttl_manage_reports'] = 'اداره التبليغات';
$LNG['admin_ttl_manage_ads'] = 'ادااره الاعلانات';

$LNG['admin_desc_general'] = 'تغيير الاعدادت العامه للموقع';
$LNG['admin_desc_users_settings'] = 'تغيير الاعدادت العامه للاعضاء';
$LNG['admin_desc_themes']  = 'تغيير مدخل الموقع';
$LNG['admin_desc_security'] = 'تغيير كلمه سر الاداره';
$LNG['admin_desc_users'] = 'اداره المستخدمين المسجلين';
$LNG['admin_desc_stats'] = 'احصائيات المستخدمين والموقع';
$LNG['admin_desc_edit_users'] = 'تعديل اعدادات المستخدم';
$LNG['admin_desc_manage_reports'] = 'اداره تبليغات الرسائل والمنشورات';
$LNG['admin_desc_manage_ads'] = 'ادااره الوحدات الاعلانيه في الموقع.';

$LNG['admin_ttl_title'] = 'العنوان';
$LNG['admin_sub_title'] = 'عنوان الموقع';

$LNG['admin_ttl_captcha'] = 'كود التحقق';
$LNG['admin_sub_captcha'] = 'ايقاف كود التحقق عند التسجيل';

	  	
$LNG ['admin_ttl_sidebar'] = 'القائمة';
$LNG ['admin_ttl_general'] = 'الإعدادات العامة';
$LNG ['admin_ttl_security'] = 'إعدادات كلمة المرور';
$LNG ['admin_ttl_themes'] = 'المواضيع';
$LNG ['admin_ttl_users'] = 'إدارة المستخدمين';
$LNG ['admin_ttl_stats'] = 'إحصائيات';
$LNG ['admin_ttl_users_settings'] = 'إعدادات المستخدم ';
$LNG ['admin_ttl_manage_reports'] = 'تقارير إدارة';
$LNG ['admin_ttl_manage_ads'] = 'إدارة إعلانات';

$LNG ['admin_desc_general'] = 'تغيير إعدادات الموقع العامة.';
$LNG ['admin_desc_users_settings'] = 'تغيير إعدادات المستخدمين العامة.';
$LNG ['admin_desc_themes'] = 'تغيير واجهة الموقع.';
$LNG ['admin_desc_security'] = 'تغيير كلمة مرور المسؤول الخاصة بك.';
$LNG ['admin_desc_users'] = 'إدارة المستخدمين المسجلين.';
$LNG ['admin_desc_stats'] = 'المستخدمين وإحصائيات الموقع';
$LNG ['admin_desc_edit_users'] = 'تحرير إعدادات المستخدم';
$LNG ['admin_desc_manage_reports'] = 'إدارة رسائل تم الإبلاغ عنها والتعليقات.';
$LNG ['admin_desc_manage_ads'] = 'إدارة الوحدات للإعلانات site\.';

$LNG ['admin_ttl_title'] = 'العنوان';
$LNG ['admin_sub_title'] = 'الموقع \ عنوان';

$LNG ['admin_ttl_captcha'] = 'كود التحقق';
$LNG ['admin_sub_captcha'] = 'تمكين كلمة التحقق في التسجيل';

$LNG ['admin_ttl_timestamp'] = 'الطابع الزمني';
$LNG ['admin_sub_timestamp'] = 'الرسائل والتعليقات والدردشة نوع الطوابع الزمنية';

$LNG ['admin_ttl_msg_perpage'] = 'رسائل';
$LNG ['admin_sub_msg_perpage'] = 'عدد الرسائل في الصفحة الواحدة';

$LNG ['admin_ttl_com_perpage'] = 'تعليقات';
$LNG ['admin_sub_com_perpage'] = 'عدد التعليقات لكل رسالة';

$LNG ['admin_ttl_chat_perpage'] = 'دردشة';
$LNG ['admin_sub_chat_perpage'] = 'عدد محادثات الدردشة في الصفحة الواحدة';

$LNG ['admin_ttl_smiles'] = 'الرموز';
$LNG ['admin_sub_smiles'] = ' الهاتفيةالسماح وتحويل القصيرة على الرسائل والتعليقات والدردشة في المشاعر';

$LNG['admin_ttl_nperpage'] = 'الاشعارات';
$LNG['admin_sub_nperpage'] = 'عدد الاشعارات التي تضهر في منطقه الاشعارات';

$LNG['admin_ttl_qperpage'] = 'بحث';
$LNG['admin_sub_qperpage'] = 'عدد نتائج البحث التي تضهر في صفحه البحث';
$LNG ['admin_ttl_msg_limit'] = 'حد رسائل';
$LNG ['admin_sub_msg_limit'] = 'عدد الأحرف المسموح بها لكل رسالة';

$LNG ['admin_ttl_chat_limit'] = 'حدود الدردشة';
$LNG ['admin_sub_chat_limit'] = 'عدد الأحرف المسموح بها المحادثة';

$LNG ['admin_ttl_email_user'] = 'ايميل المستخدمين';
$LNG ['admin_sub_email_user'] = 'البريد الإلكتروني للمستخدمين في التسجيل';

$LNG ['admin_ttl_notificationsm'] = 'اشعارات الرسائل';
$LNG ['admin_sub_notificationsm'] = 'فاصل التحديث للتحقق من وجود رسائل جديدة';

$LNG ['admin_ttl_notificationsn'] = 'اشعارات المناسبات';
$LNG ['admin_sub_notificationsn'] = 'فاصل التحديث للتحقق من الإخطارات الجديدة بأحداث';

$LNG ['admin_ttl_rperpage'] = 'تبليغات';
$LNG ['admin_sub_rperpage'] = 'عددالتبليغات بالصفحة(ادارة التبليغات)';


$LNG ['admin_ttl_chatrefresh'] = 'تحديث الدردشة';
$LNG ['admin_sub_chatrefresh'] = 'الوقت كيف في كثير من الأحيان بتحديث إطار المحادثة مع رسائل جديدة';

$LNG ['admin_ttl_timeonline'] = 'المستخدمين على شبكة الإنترنت';
$LNG ['admin_sub_timeonline'] = 'مقدار الوقت التي سينظر فيها على الإنترنت منذ النشاط user\ الأخير ل';
$LNG['admin_ttl_uperpage'] = 'المستخدمين';
$LNG['admin_sub_uperpage'] = 'عددالمستخدمين في الصفحة (ادارة المستخدمين)';

$LNG ['admin_ttl_image_profile'] = 'حجم الصوره في البروفايل';
$LNG ['admin_sub_image_profile'] = 'الصورة للحجم المسموح به لتحميل (الغلاف الشخصية والرمزية)';

$LNG ['admin_ttl_image_format'] = 'تنسيق صورة(ملف تعريف)';
$LNG ['admin_sub_image_format'] = 'تنسيق الصورة يسمح لتحميل (الغلاف الشخصية والرمزية)، استخدم فقط gif، بابوا نيو غينيا، jpg الأخرى تنسيقات غير معتمدة';

$LNG ['admin_ttl_message_image'] = 'حجم الصورة(رسائل)';
$LNG ['admin_sub_message_image'] = 'الصورة للحجم المسموح به لتحميل (رسائل)';

$LNG ['admin_ttl_message_format'] = 'تنسيق الصورة(رسائل)';
$LNG ['admin_sub_message_format'] = 'صورة تنسيق يسمح لتحميل (رسائل)، استخدام فقط gif، بابوا نيو غينيا، jpg الأخرى تنسيقات غير معتمدة';

$LNG ['admin_ttl_censor'] = 'الرقيب';
$LNG ['admin_sub_censor'] = 'الكلمات يكون للرقابة (مقسوماً على [فاصلة])';

$LNG ['admin_ttl_ad1'] = 'وحدة إعلانية1';
$LNG ['admin_sub_ad1'] = 'إعلان الوحدة1 (أسفل صفحة الترحيب)';

$LNG ['admin_ttl_ad2'] = 'وحدة إعلانية2';
$LNG ['admin_sub_ad2'] = 'وحدة الإعلان2 (الشريط الجانبي [الصفحة الجدول الزمني])';

$LNG ['admin_ttl_ad3'] = 'وحدة إعلانية3';
$LNG ['admin_sub_ad3'] = 'وحدة الإعلان3 (الشريط الجانبي [صفحة أخبار آر])';

$LNG ['admin_ttl_ad4'] = 'وحدة إعلانية4';
$LNG ['admin_sub_ad4'] = 'إعلان الوحدة4 (الشريط الجانبي [الصفحة الشخصية])';

$LNG ['admin_ttl_ad5'] = 'وحدة إعلانية5';
$LNG ['admin_sub_ad5'] = 'وحدة الإعلان5 (الشريط الجانبي [رسائل فردية])';

$LNG ['admin_ttl_ad6'] = 'إعلان وحدة6';
$LNG ['admin_sub_ad6'] = 'وحدة الإعلان6 (الشريط الجانبي [صفحة البحث الناس])';

$LNG['admin_ttl_password'] = 'كلمه السر';
$LNG['admin_sub_password'] = 'اذا لم تود تغييرها اتركها فارغه';

$LNG['admin_ttl_edit'] = 'تعديل';
$LNG['admin_ttl_edit_profile'] = 'تحرير الملف الشخصي';

$LNG['admin_ttl_delete'] = 'حذف';
$LNG['admin_ttl_delete_profile'] = 'حذف الحساب الشخصي ';

$LNG['admin_ttl_mail'] = 'البريد الالكتروني';
$LNG['admin_ttl_username'] = 'اسم المستخدم';
$LNG ['admin_ttl_id'] = 'معرف'; 

$LNG ['admin_ttl_mprivacy'] = 'نوع الرسالة';
$LNG ['admin_sub_mprivacy'] = 'رسالة الخصوصية ل User\ بشكل افتراضي (يمكن أن يتغير من إعدادات user\s)';
$LNG['admin_ttl_notificationl'] = 'اشعار الاعجاب';
$LNG['admin_sub_notificationl'] = 'ايقاف الاعلامات والاشعارات ل <strong>الاعجابات</strong> (يمكن تغييره من اعدادات المستخدم)';

$LNG['admin_ttl_notificationc'] = 'اشعار التعليقات';
$LNG['admin_sub_notificationc'] = 'ايقاف الاعلام والاشعار ل <strong>التعليقات</strong> (يمكن تغييره من اعدادات المستخدم)';

$LNG['admin_ttl_notifications'] = 'اشعار الرسائل';
$LNG['admin_sub_notifications'] = ' ايقاف الاعلام والاشعار ل <strong>مشاركة الرسائل</strong> (يمكن تغييره من اعدادات المستخدم)';

$LNG['admin_ttl_notificationd'] = 'اشعار الدردشة';
$LNG['admin_sub_notificationd'] = ' ايقاف الاعلام والاشعار ل <strong>الدردشة</strong> (يمكن تغييره من اعدادات المستخدم)';

$LNG['admin_ttl_notificationf'] = 'اشعار الاصدقاء';
$LNG['admin_sub_notificationf'] = ' ايقاف الاعلام والاشعار ل <strong>الاصدقاء Additions</strong> (يمكن تغييره من اعدادات المستخدم)';

$LNG['admin_ttl_sound_nn'] = 'صوت الاشعار';
$LNG['admin_sub_sound_nn'] = 'تشغيل الصوت للاشعارات الجديدة (يمكن تغييره من اعدادات المستخدم)';

$LNG['admin_ttl_sound_nc'] = 'صوت الدردشة';
$LNG['admin_sub_sound_nc'] = 'تفعيل الصوت للرسالة الجديدة (يمكن تغييره من اعدادات المستخدم)';

$LNG['admin_ttl_email_comment'] = 'رسالة عند التعليق';
$LNG['admin_sub_email_comment'] = 'تفعيل ارسال رسالة عندما يعلق شخص على منشورك الى الايميل';

$LNG['admin_ttl_email_like'] = 'رسالة عند الاعجاب';
$LNG['admin_sub_email_like'] = 'يعجب شخص بمنشور لك الى الايميل تفعيل ارسال رسالة عندما يعلق شخص على ';

$LNG['admin_ttl_email_new_friend'] = 'رسالة عند الصداقة';
$LNG['admin_sub_email_new_friend'] = 'تفعيل ارسال رسالة الى الايميل عند طلب الصداقة الجديد';

$LNG['admin_ttl_ilimit'] = 'حد. الصور';
$LNG['admin_sub_ilimit'] = 'الحد الاقصى للصور المرفوعة في الرسالة';

$LNG['admin_ttl_wholiked'] = 'من اعجب';
$LNG['admin_sub_wholiked'] = 'عدد من صور الشخصية تظهر بالقرب من الاعجاب';

$LNG['admin_ttl_ronline'] = 'الاشخاص المتواجدين';
$LNG['admin_sub_ronline'] = 'عدد الاشخاص الذين سوف يظهرو في صفحة المنشورات/صفحة الاشتراكات (الشريط الجانبي).';

$LNG['admin_ttl_nperwidget'] = 'تصنيف الاشعارات';
$LNG['admin_sub_nperwidget'] = ' عدد الصور التي سوف تظهر بتصنيف (اعجابات, تعليقات, رسائل)';

$LNG['per_page'] = '/ صفحة';
$LNG['second'] = 'ثانية';
$LNG['seconds'] = 'ثوان';
$LNG['minute'] = 'دقيقة';
$LNG['minutes'] = 'دقائق';
$LNG['hour'] = 'ساعة';
$LNG['recommended'] = 'موصى به';
$LNG['edit_user'] = 'تعديل مستخدم';
$LNG['username_to_edit'] = 'ادخل اسم المستخدم';
$LNG['username_to_edit_sub'] = 'ادخل اسم المستخدم المراد تعديله';
// STATS //
$LNG['user_registration'] = 'الاعضاء المسجلين';
$LNG['users_today'] = 'اليوم';
$LNG['users_this_month'] = 'هذا الشهر';
$LNG['users_last_30'] = 'اخر 30 يوم';
$LNG['total_users'] = 'المجموع';

$LNG['messages_and_comments'] = 'الرسائل & التعليقات';
$LNG['reports_title'] = 'التبليغات - (الرسائل %26 التعليقات)';
$LNG['total_messages'] = 'جميع الرسائل';
$LNG['public_messages'] = 'رسائل عامة';
$LNG['private_messages'] = 'رسائل خاصة';
$LNG['total_comments'] = 'جميع التعليقات';
$LNG['stats_total'] = 'مجموع';
$LNG['stats_public'] = 'عام';
$LNG['stats_private'] = 'خاص';
$LNG['stats_reports'] = 'تبليغات';
$LNG['total_reports'] = 'جميع التبليغات';
$LNG['pending_reports'] = 'في انتظار التقارير';
$LNG['safe_reports'] = 'تبليغات المؤمنة';
$LNG['deleted_reports'] = 'حذف التبليغات';
$LNG['likes_today'] = 'الاعجابات اليوم';
$LNG['likes_this_month'] = 'الاعجابات هذا الشهر';
$LNG['likes_last_30'] = 'اخر 30 يوم';
$LNG['likes_total'] = 'مجموع الاعجابات';
$LNG['likes'] = 'الاعجابات';
// MANAGE REPORTS //
$LNG['admin_reports_id'] = 'ID';
$LNG['admin_reports_view'] = 'عرض جميع التبليغات';
$LNG['admin_reports_type'] = 'نوع';
$LNG['admin_reports_by'] = 'بلغت من قبل';
$LNG['admin_reports_safe'] = 'علامه امنه';
$LNG['admin_reports_delete'] = 'حذف';
$LNG['admin_reports_ttl_safe'] = 'علامه امنه';
// LIKES //
$LNG['already_liked'] = 'انت فعلا معجب بهذه الرساله';
$LNG['already_disliked'] = 'انت فعلا قمت بتصنيف هذه الرساله كغير مرغوب فيها';
$LNG['like'] = 'اعجبني';
$LNG['dislike'] = 'لم يعجبني';
$LNG['like_message_not_exist'] = 'هذا الرساله غير موجوده او حذفت';
$LNG['liked_this'] = 'معجب بهذا';
// MISC //
$LNG['sponsored'] = 'برعايه';
$LNG['censored'] = '<strong>censored</strong>';
$LNG['new_like_notification'] = '<strong><a href="%s">%s</a></strong>يحب<strong><a href="%s">نشر</a></strong>';
$LNG['new_comment_notification'] = '<strong><a href="%s">%s</a></strong> علق في <strong><a href="%s">منشور</a></strong>';
$LNG['new_message_notification'] = '<strong><a href="%s">%s</a></strong>نشر جديد <strong><a href="%s">رساله</a></strong>';
$LNG['new_chat_notification'] = '<strong><a href="%s">%s</a></strong> sent you a <strong><a href="%s">الدردشه</a></strong>';
$LNG['change_password'] = 'تغيير كلمه السر';
$LNG['enter_new_password'] = 'ادخل كلمه سرك';
$LNG['enter_reset_key'] = 'ادخل رمز الاستعادة';
$LNG['enter_username'] = 'ادخل كلمه السر';
$LNG['reset_key'] = 'استعاده';
$LNG['new_password'] = 'كلمه سر جديده';
$LNG['password_recovery'] = 'استعاده كلمه السر';
$LNG['password'] = 'كلمه السر';
$LNG['recover']	= 'استعاده';
$LNG['recover_sub_username'] = 'ادخل اسم المستخدم الذي تود استعاده كلمه سره!';// PROFILE //
$LNG['profile_not_exist'] = 'متاسفون.لكن هذا الحساب غير متطابق';
$LNG['profile_semi_private'] = 'متاسفون.لا يمكنك رؤيه منشورات هذا المستخدم فقط الاصدقاء من يتمكنون من الرؤيه';
$LNG['profile_private'] = 'ناسف لكن هذا الحساب خصوصي جدا.';
$LNG['profile_not_exist_ttl'] = 'الحساب غير متطابق';
$LNG['profile_semi_private_ttl'] = 'الحساب محمي بالخصوصيه';
$LNG['profile_private_ttl'] = 'الحساب خصوصي';
$LNG['add_friend'] = 'اضافه كصديق';
$LNG['remove_friend'] = 'حذف صديق';
$LNG['profile_about'] = 'عن';
$LNG['profile_born'] = 'الولاده';
$LNG['profile_location'] = 'الموقع';
$LNG['profile_website'] = 'البدايه';
$LNG['profile_view_site'] = 'عرض صفحه الويب';
$LNG['profile_view_profile'] = 'عرض الحساب';
$LNG['profile_bio']	= 'Bio';
$LNG['new_messages_posted'] = 'رساله جديده وصلت.اضغط للتحديث';
$LNG['verified_user'] = 'مستخدم مفعل';
$LNG['edit_profile_cover'] = 'تغيير الصوره الشخصيه';
$LNG['view_all_notifications'] = 'اظهر المزيد من الاشعارات';
$LNG['close_notifications'] = 'اغلق الاشعارات';
$LNG['notifications_settings'] = 'اعدادات الاشعارات';
$LNG['no_notifications'] = 'لا اشعارات الان';
$LNG['search_title'] = 'نتائج البحث';
$LNG['view_all_results'] = 'عرض كافه النتائج';
$LNG['close_results'] = 'غلق النتائج';
$LNG['no_results'] = 'لا يوجد نتائج بحث .حاول البحث مجددا';
$LNG['no_results_ttl'] = 'نتائج البحث';
$LNG['search_for_users'] = 'البحث عن المستخدمين';
$LNG['follows'] = 'المتابعين';
$LNG['followed_by'] = 'متابع من قبل';
$LNG['people'] = 'الناس';
// GENERAL //
$LNG['title_profile'] = 'تعديل حسابي';
$LNG['title_feed'] = 'اخر المنشورات';
$LNG['title_post'] = 'نشر';
$LNG['title_messages'] = 'الرسائل';
$LNG['title_settings'] = 'الاعدادات';
$LNG['title_timeline'] = 'الجدول الزمني';
$LNG['title_search'] = 'بحث';
$LNG['title_notifications'] = 'الاشعارات';
$LNG['title_admin']	= '';
$LNG['on'] = 'تشغيل';
$LNG['off'] = 'اغلاق';
$LNG['none'] = 'عادي';
$LNG['pages'] = 'صفحات';
$LNG['search_for_people'] = 'بحث عن الناس..صفحات الخ';
$LNG['new_message'] = 'رساله جديده';
$LNG['privacy_policy'] = 'سياسه الخصوصيه';
$LNG['terms_of_use'] = 'شروط الاستخدام';
$LNG['about'] = 'من نحن';
$LNG['disclaimer'] = 'التنازل';
$LNG['contact'] = 'اتصل بنا';
$LNG['api_documentation'] = 'API توثيق';
$LNG['developers'] = 'المطورين';
$LNG['language'] = 'اللغة';


// MONTHS
$LNG['month_1'] = 'يناير';
$LNG['month_2'] = 'فبراير';
$LNG['month_3'] = 'مارس';
$LNG['month_4'] = 'ابريل';
$LNG['month_5'] = 'مايو';
$LNG['month_6'] = 'يونيو';
$LNG['month_7'] = 'يوليو';
$LNG['month_8'] = 'اغصسطس';
$LNG['month_9'] = 'سبتمبر';
$LNG['month_10'] = 'اكتوبر';
$LNG['month_11'] = 'نوفمبر';
$LNG['month_12'] = 'ديسمبر';


// Remember me
$LNG['remeber_me'] = 'تذكرني';

// New Account
$LNG['new_account'] = 'لست مسجلا سجل الان?';


?>

