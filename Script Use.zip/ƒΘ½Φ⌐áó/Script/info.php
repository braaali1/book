<?php
// Software Name
$name = 'phpDolphin';

// Software Author
$author = 'phpDolphin';

// Software URL
$url = 'http://phpdolphin.com';

// Software Version
$version = '2.1.6';
?>