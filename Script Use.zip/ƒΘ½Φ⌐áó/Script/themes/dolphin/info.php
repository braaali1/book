<?php
// Theme Name
$name = 'Dolphin';

// Theme Author
$author = 'phpDolphin';

// Theme URL
$url = 'https://phpdolphin.com';

// Theme Version
$version = '1.4.3';
?>